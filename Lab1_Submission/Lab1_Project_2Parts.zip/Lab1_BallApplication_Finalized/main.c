// EEC172 Lab1_BallApplication_Finalized
// Weidong Wu
// Chen Chen

// Standard includes
#include <string.h>

// Driverlib includes
#include "hw_types.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "hw_ints.h"
#include "spi.h"
#include "gpio.h"
#include "rom.h"
#include "rom_map.h"
#include "utils.h"
#include "prcm.h"
#include "uart.h"
#include "interrupt.h"

// Common Interfaces and PinMux includes
#include "uart_if.h"
#include "i2c_if.h"
// Also need to copy i2c_if.c to the project or else will give MACRO definition error
// ASK TA Why is that?! What are the differences between the one from i2c_demo and include folder?
#include "pin_mux_config.h"
// PLEASE remember to set the pins to work with UART and I2C communication!

// OLED Specilized includes
#include "Adafruit_SSD1351.h"
#include "Adafruit_GFX.h"
#include "glcdfont.h"

//
// 					-----original test.c without library includes-----
//

/* These functions are based on the Arduino test program at
*  https://github.com/adafruit/Adafruit-SSD1351-library/blob/master/examples/test/test.ino
*
*  You can use these high-level routines to implement your
*  test program.
*/

// TODO Configure SPI port and use these libraries to implement
// an OLED test program. See SPI example program.

extern int cursor_x;
extern int cursor_y;

float p = 3.1415926;

// Color definitions
#define	BLACK           0x0000
#define	BLUE            0x001F
#define	GREEN           0x07E0
#define CYAN            0x07FF
#define	RED             0xF800
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0
#define WHITE           0xFFFF

//*****************************************************************************
//  function delays 3*ulCount cycles
void delay(unsigned long ulCount){
	int i;

  do{
    ulCount--;
		for (i=0; i< 65535; i++) ;
	}while(ulCount);
}


//*****************************************************************************
void testfastlines(unsigned int color1, unsigned int color2) {
	unsigned int x;
	unsigned int y;

   fillScreen(BLACK);
   for (y=0; y < height()-1; y+=8) {
     drawFastHLine(0, y, width()-1, color1);
   }
	 delay(100);
   for (x=0; x < width()-1; x+=8) {
     drawFastVLine(x, 0, height()-1, color2);
   }
	 delay(100);
}

//*****************************************************************************

void testdrawrects(unsigned int color) {
	unsigned int x;

 fillScreen(BLACK);
 for (x=0; x < height()-1; x+=6) {
   drawRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color);
	 delay(10);
 }
}

//*****************************************************************************

void testfillrects(unsigned int color1, unsigned int color2) {

	unsigned char x;

 fillScreen(BLACK);
 for (x=height()-1; x > 6; x-=6) {
   fillRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color1);
   drawRect((width()-1)/2 -x/2, (height()-1)/2 -x/2 , x, x, color2);
	 delay(10);
 }
}

//*****************************************************************************

void testfillcircles(unsigned char radius, unsigned int color) {
	unsigned char x;
	unsigned char y;

  for (x=radius; x < width()-1; x+=radius*2) {
    for (y=radius; y < height()-1; y+=radius*2) {
      fillCircle(x, y, radius, color);
			delay(10);
    }
  }
}

//*****************************************************************************

void testdrawcircles(unsigned char radius, unsigned int color) {
	unsigned char x;
	unsigned char y;

  for (x=0; x < width()-1+radius; x+=radius*2) {
    for (y=0; y < height()-1+radius; y+=radius*2) {
      drawCircle(x, y, radius, color);
			delay(10);
    }
  }
}

//*****************************************************************************

void testtriangles() {
  int color = 0xF800;
  int t;
  int w = width()/2;
  int x = height()-1;
  int y = 0;
  int z = width()-1;

  fillScreen(BLACK);
  for(t = 0 ; t <= 15; t+=1) {
    drawTriangle(w, y, y, x, z, x, color);
    x-=4;
    y+=4;
    z-=4;
    color+=100;
		delay(10);
  }
}

//*****************************************************************************

void testroundrects() {
  int color = 100;

	int i;
  int x = 0;
  int y = 0;
  int w = width();
  int h = height();

  fillScreen(BLACK);

  for(i = 0 ; i <= 24; i++) {
    drawRoundRect(x, y, w, h, 5, color);
    x+=2;
    y+=3;
    w-=4;
    h-=6;
    color+=1100;
  }
}

//*****************************************************************************
void testlines(unsigned int color) {
	unsigned int x;
	unsigned int y;

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(0, 0, x, height()-1, color);
   }
	 delay(10);
   for (y=0; y < height()-1; y+=6) {
     drawLine(0, 0, width()-1, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(width()-1, 0, x, height()-1, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(width()-1, 0, 0, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(0, height()-1, x, 0, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(0, height()-1, width()-1, y, color);
   }
	 delay(100);

   fillScreen(BLACK);
   for (x=0; x < width()-1; x+=6) {
     drawLine(width()-1, height()-1, x, 0, color);
   }
	 delay(100);
   for (y=0; y < height()-1; y+=6) {
     drawLine(width()-1, height()-1, 0, y, color);
   }
	 delay(100);

}

//*****************************************************************************

void lcdTestPattern(void)
{
  unsigned int i,j;
  goTo(0, 0);

  for(i=0;i<128;i++)
  {
    for(j=0;j<128;j++)
    {
      if(i<16){writeData(RED>>8); writeData((unsigned char) RED);}
      else if(i<32) {writeData(YELLOW>>8);writeData((unsigned char) YELLOW);}
      else if(i<48){writeData(GREEN>>8);writeData((unsigned char) GREEN);}
      else if(i<64){writeData(CYAN>>8);writeData((unsigned char) CYAN);}
      else if(i<80){writeData(BLUE>>8);writeData((unsigned char) BLUE);}
      else if(i<96){writeData(MAGENTA>>8);writeData((unsigned char) MAGENTA);}
      else if(i<112){writeData(BLACK>>8);writeData((unsigned char) BLACK);}
      else {writeData(WHITE>>8); writeData((unsigned char) WHITE);}
    }
  }
}
/**************************************************************************/
void lcdTestPattern2(void)
{
  unsigned int i,j;
  goTo(0, 0);

  for(i=0;i<128;i++)
  {
    for(j=0;j<128;j++)
    {
      if(j<16){writeData(RED>>8); writeData((unsigned char) RED);}
      else if(j<32) {writeData(YELLOW>>8);writeData((unsigned char) YELLOW);}
      else if(j<48){writeData(GREEN>>8);writeData((unsigned char) GREEN);}
      else if(j<64){writeData(CYAN>>8);writeData((unsigned char) CYAN);}
      else if(j<80){writeData(BLUE>>8);writeData((unsigned char) BLUE);}
      else if(j<96){writeData(MAGENTA>>8);writeData((unsigned char) MAGENTA);}
      else if(j<112){writeData(BLACK>>8);writeData((unsigned char) BLACK);}
      else {writeData(WHITE>>8);writeData((unsigned char) WHITE);}
    }
  }
}


/**************************************************************************/

//						----END OF test.c----

//*****************************************************************************
//                      MACRO DEFINITIONS
//*****************************************************************************
#define APP_NAME                "Lab1: Mysterious Ball"
#define FOREVER                 1
#define FAILURE                 -1
#define SUCCESS                 0
#define UART_PRINT              Report
#define SPI_IF_BIT_RATE			100000
#define TR_BUFF_SIZE			100
#define DIFFICULTY				10	// Highest 1
#define BALL_RADIUS				1
#define OLED_LOWER_BOUND		1
#define OLED_UPPER_BOUND		126
#define UPPER_TILT_LIMIT		127	// Lowest1; Highest 127
#define LOWER_TILT_LIMIT		256 - UPPER_TILT_LIMIT	// 2's compliment, a +ve int to represent -ve

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************

#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif
//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************

//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void)
{
/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
  //
  // Set vector table base
  //
#if defined(ccs)
    MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
#endif
#if defined(ewarm)
    MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
    //
    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}

//*****************************************************************************
//
//! Application startup display on UART
//!
//! \param  none
//!
//! \return none
//!
//*****************************************************************************
static void
DisplayBanner(char * AppName)
{

    Report("\n\n\n\r");
    Report("\t\t *************************************************\n\r");
    Report("\t\t      CC3200 %s Application       \n\r", AppName);
    Report("\t\t *************************************************\n\r");
    Report("\n\n\n\r");
}

static void
SeperateReadings()
{

    Report("\n\r");
    Report("\t\t *************************************************\n\r");
    Report("\t\t Current x, y-Axis Acceleration Data\n\r");
    Report("\n\r");
}


//*****************************************************************************
//
//! Display the buffer contents over I2C
//!
//! \param  pucDataBuf is the pointer to the data store to be displayed
//! \param  ucLen is the length of the data to be displayed
//!
//! \return none
//!
//*****************************************************************************
void
DisplayBuffer(unsigned char *pucDataBuf, unsigned char ucLen)
{
    unsigned char ucBufIndx = 0;
    UART_PRINT("Read contents");
    UART_PRINT("\n\r");
    while(ucBufIndx < ucLen)
    {
        UART_PRINT(" 0x%x, ", pucDataBuf[ucBufIndx]);
        ucBufIndx++;
        if((ucBufIndx % 8) == 0)
        {
            UART_PRINT("\n\r");
        }
    }
    UART_PRINT("\n\r");
}

//*****************************************************************************
//
// Fetch New Data Flag and Acceleration Data from 0x18 (Accelerometer) 0x2(New Flag) and 0x3(Data)
// Return TRUE if the data has been updated
//
//*****************************************************************************

int fetchAccelerationData(unsigned char* aucRdDataBuf) {
    unsigned char ucDevAddr = 0x18;	// Addr of the Accelerometer
    unsigned char ucRegOffset = 0x02;	// Starting from the New Flag of x
    unsigned char ucRdLen = 4;	// Fetch the New Flags and Data for x, y.
    							// Data for z have been left out.

    //
	// Read x-accele data from 0x18 0x2 (new bit) and 0x3 (data)
    // Read y-accele data from 0x18 0x4 (new bit) and 0x5 (data)
    // And put into aucRdDataBuf sequentially: [0], [1], [2], [3]
    //
    // Write the register address to be read from.
    // Stop bit implicitly assumed to be 0.
    //
    I2C_IF_Write(ucDevAddr,&ucRegOffset,1,0);

    //
    // Read the specified length of data
    //
    I2C_IF_Read(ucDevAddr, &aucRdDataBuf[0], ucRdLen);

    return (aucRdDataBuf[0] || aucRdDataBuf[2]);	// True if either of the data changes
}

void
updatePositions(int* x, int* y, unsigned char* aucRdDataBuf) {
	int xOffset = 0;
	int yOffset = 0;
	int newX = *x;
	int newY = *y;	// dereference is *


	//
	// Update virtual offsets according to accele data, NOT OLED offset!
	// Effective Range: -TILT_LIMIT to TILT_LIMIT.
	//
	if (aucRdDataBuf[1] > 0 && aucRdDataBuf[1] <= UPPER_TILT_LIMIT) { xOffset = aucRdDataBuf[1]; }
	else if (aucRdDataBuf[1] > UPPER_TILT_LIMIT && aucRdDataBuf[1] < 128) { xOffset = UPPER_TILT_LIMIT; }
	else if (aucRdDataBuf[1] >= LOWER_TILT_LIMIT && aucRdDataBuf[1] < 256) { xOffset = aucRdDataBuf[1] - 256; }
	else if (aucRdDataBuf[1] > 128 && aucRdDataBuf[1] < LOWER_TILT_LIMIT) { xOffset = -UPPER_TILT_LIMIT; }
	else {}

	if (aucRdDataBuf[3] > 0 && aucRdDataBuf[3] <= UPPER_TILT_LIMIT) { yOffset = aucRdDataBuf[3]; }
	else if (aucRdDataBuf[3] > UPPER_TILT_LIMIT && aucRdDataBuf[3] < 128) { yOffset = UPPER_TILT_LIMIT; }
	else if (aucRdDataBuf[3] >= LOWER_TILT_LIMIT && aucRdDataBuf[3] < 256) { yOffset = aucRdDataBuf[3] - 256; }
	else if (aucRdDataBuf[3] > 128 && aucRdDataBuf[3] < LOWER_TILT_LIMIT) { yOffset = -UPPER_TILT_LIMIT; }
	else {}

	// OLED Update and Set Boundary within the screen
	newX = *x + xOffset / DIFFICULTY;
	if (newX > OLED_UPPER_BOUND) { newX = OLED_UPPER_BOUND; }
	else if (newX < OLED_LOWER_BOUND) { newX = OLED_LOWER_BOUND; }
	else {}

	newY = *y + yOffset / DIFFICULTY;
	if (newY > OLED_UPPER_BOUND) { newY = OLED_UPPER_BOUND; }
	else if (newY < OLED_LOWER_BOUND) { newY = OLED_LOWER_BOUND; }
	else {}

	fillCircle(*y, *x, BALL_RADIUS, BLACK);
	fillCircle(newY, newX, BALL_RADIUS, GREEN);

	// Update x and y
	*x = newX;
	*y = newY;
}

//*****************************************************************************
//
// main function
//
//*****************************************************************************
void main()
 {
    //
    // Initialize Board configurations
    //
    BoardInit();

    //
    // Configurate PinMux
    //
    PinMuxConfig();

    //
    // Enable the SPI module clock
    //
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);


    //
    // Reset the peripheral
    //
    MAP_PRCMPeripheralReset(PRCM_GSPI);

    //
    // Reset SPI
    //
    MAP_SPIReset(GSPI_BASE);

    //
    // Configure SPI interface
    //
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                        SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_3,	// Must be 3: Polarity = Phase = 1
                        (SPI_SW_CTRL_CS |
                        SPI_4PIN_MODE |
                        SPI_TURBO_OFF |
						SPI_CS_ACTIVELOW |	// LOW!!!!
                        SPI_WL_8));

    //
    // Enable SPI for communication
    //
    MAP_SPIEnable(GSPI_BASE);


    // initialize OLED
    Adafruit_Init();

    //
    // Configuring UART
    //
    InitTerm();

    //
    // I2C Init
    //
    I2C_IF_Open(I2C_MASTER_MODE_FST);

    DisplayBanner(APP_NAME);

    //
    // Main Function for the Ball Control
    //

    // Clear screen
    fillScreen(BLACK);

    // Initialize Center Ball
    int x = 64;
    int y = 64;
    fillCircle(y, x, BALL_RADIUS, GREEN);

    // Initialize Flag and Buffer for I2C Communication
    unsigned char aucRdDataBuf[256];
    int NewDataFlag = 0;

    while(FOREVER) {
    	NewDataFlag = fetchAccelerationData(aucRdDataBuf);
    	if (!NewDataFlag) {}
    	else {
    		updatePositions(&x, &y, aucRdDataBuf);
    	}

    	//
    	// Display Acceleration Data to Terminal
    	//
    	SeperateReadings();
    	Report("X-Axis: ");
    	DisplayBuffer(&aucRdDataBuf[0], 2);
    	Report("Y-Axis: ");
    	DisplayBuffer(&aucRdDataBuf[2], 2);

    	// delay(80);
    }
}

///////////////// Lagacy Code ///////////////////////
// Boundary test: Result: x = 1, y = 126
//    fillScreen(BLACK);
//    fillCircle(1, 1, 1, GREEN);
//    delay(100);
//    fillCircle(1, 126, 1, GREEN);
//    delay(100);
//    fillCircle(126, 126, 1, GREEN);
//    delay(100);
//    fillCircle(126, 1, 1, GREEN);
//
// Direction Test
// fillScreen(BLACK);
// int i = 0;
// for (i = 1; i < 126; i++) {
//    fillCircle(i, i, 1, GREEN);
// }
/////////////////////////////////////////////////////
///////////////// End of Lab1 ///////////////////////
/////////////////////////////////////////////////////
