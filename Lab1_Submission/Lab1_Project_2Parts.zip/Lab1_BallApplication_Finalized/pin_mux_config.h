#ifndef __PIN_MUX_CONFIG_H__
#define __PIN_MUX_CONFIG_H__

extern void PinMuxConfig(void);

#endif //  __PIN_MUX_CONFIG_H__
